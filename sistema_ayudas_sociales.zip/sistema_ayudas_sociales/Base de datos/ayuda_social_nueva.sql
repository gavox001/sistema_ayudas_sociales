-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 05-06-2025 a las 14:59:07
-- Versión del servidor: 9.1.0
-- Versión de PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ayuda_social`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `beneficiarios`
--

DROP TABLE IF EXISTS `beneficiarios`;
CREATE TABLE IF NOT EXISTS `beneficiarios` (
  `id_beneficiario` int NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `sexo` enum('MASCULINO','FEMENINO') NOT NULL,
  PRIMARY KEY (`id_beneficiario`),
  UNIQUE KEY `cedula` (`cedula`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `beneficiarios`
--

INSERT INTO `beneficiarios` (`id_beneficiario`, `cedula`, `nombre`, `apellido`, `fecha_nacimiento`, `sexo`) VALUES
(1, '23424367', 'Anabell Cristina', 'Rivas Hernandez', '0000-00-00', 'MASCULINO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
CREATE TABLE IF NOT EXISTS `bitacora` (
  `id_bitacora` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `accion` varchar(100) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_usuario` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_bitacora`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `bitacora`
--

INSERT INTO `bitacora` (`id_bitacora`, `id_usuario`, `accion`, `fecha`, `ip_usuario`) VALUES
(1, 1, 'Inicio de sesión', '2025-06-02 15:42:18', '::1'),
(2, 1, 'Inicio de sesión', '2025-06-02 15:59:53', '::1'),
(3, 1, 'Inicio de sesión', '2025-06-02 16:20:49', '::1'),
(4, 1, 'Inicio de sesión', '2025-06-02 16:28:46', '::1'),
(5, 1, 'Inicio de sesión', '2025-06-03 08:45:47', '::1'),
(6, 1, 'Inicio de sesión', '2025-06-03 09:50:38', '::1'),
(7, 1, 'Inicio de sesión', '2025-06-03 11:10:28', '::1'),
(8, 1, 'Inicio de sesión', '2025-06-03 11:17:10', '::1'),
(9, 1, 'Inicio de sesión', '2025-06-03 11:19:47', '::1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `casos`
--

DROP TABLE IF EXISTS `casos`;
CREATE TABLE IF NOT EXISTS `casos` (
  `id_caso` int NOT NULL AUTO_INCREMENT,
  `id_solicitante` int NOT NULL,
  `id_beneficiario` int NOT NULL,
  `tipo_solicitud` varchar(50) NOT NULL,
  `tipo_caso` varchar(50) NOT NULL,
  `nivel_caso` varchar(50) DEFAULT NULL,
  `descripcion_solicitud` text,
  `descripcion_general` text,
  `detalle_items` text,
  `nombre_medicamento` varchar(100) DEFAULT NULL,
  `cantidad_medicamento` int DEFAULT NULL,
  `presentacion` varchar(50) DEFAULT NULL,
  `institucion` varchar(100) DEFAULT NULL,
  `codigo_oficio_prefijo` varchar(10) DEFAULT NULL,
  `codigo_oficio_numero` int DEFAULT NULL,
  `codigo_oficio_anio` year DEFAULT NULL,
  `id_estado` int NOT NULL,
  `id_municipio` int NOT NULL,
  `id_parroquia` int NOT NULL,
  `id_ubch` int NOT NULL,
  `id_comunidad` int NOT NULL,
  `estatus_caso` varchar(50) DEFAULT NULL,
  `estatus407` varchar(50) DEFAULT NULL,
  `fecha_solicitud` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_caso`),
  KEY `id_solicitante` (`id_solicitante`),
  KEY `id_beneficiario` (`id_beneficiario`),
  KEY `id_estado` (`id_estado`),
  KEY `id_municipio` (`id_municipio`),
  KEY `id_parroquia` (`id_parroquia`),
  KEY `id_ubch` (`id_ubch`),
  KEY `id_comunidad` (`id_comunidad`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `casos`
--

INSERT INTO `casos` (`id_caso`, `id_solicitante`, `id_beneficiario`, `tipo_solicitud`, `tipo_caso`, `nivel_caso`, `descripcion_solicitud`, `descripcion_general`, `detalle_items`, `nombre_medicamento`, `cantidad_medicamento`, `presentacion`, `institucion`, `codigo_oficio_prefijo`, `codigo_oficio_numero`, `codigo_oficio_anio`, `id_estado`, `id_municipio`, `id_parroquia`, `id_ubch`, `id_comunidad`, `estatus_caso`, `estatus407`, `fecha_solicitud`) VALUES
(1, 1, 1, 'NO DEFINIDO', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 'PENDIENTE', NULL, '2025-06-03 10:35:19'),
(2, 2, 2, 'NO DEFINIDO', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 'PENDIENTE', NULL, '2025-06-03 11:02:11'),
(3, 1, 1, 'NO DEFINIDO', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 'PENDIENTE', NULL, '2025-06-03 14:56:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comunidades`
--

DROP TABLE IF EXISTS `comunidades`;
CREATE TABLE IF NOT EXISTS `comunidades` (
  `id_comunidad` int NOT NULL AUTO_INCREMENT,
  `id_parroquia` int NOT NULL,
  `nombre_comun` varchar(100) NOT NULL,
  PRIMARY KEY (`id_comunidad`),
  KEY `id_parroquia` (`id_parroquia`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `comunidades`
--

INSERT INTO `comunidades` (`id_comunidad`, `id_parroquia`, `nombre_comun`) VALUES
(1, 1, 'Comunidad Candelaria Norte'),
(2, 1, 'Comunidad Candelaria Sur'),
(3, 2, 'Comunidad Peña Alta'),
(4, 2, 'Comunidad Peña Baja'),
(5, 3, 'Comunidad Bejuma Central'),
(6, 4, 'Comunidad El Centro Maracay'),
(7, 5, 'Comunidad Turmero Antiguo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados`
--

DROP TABLE IF EXISTS `estados`;
CREATE TABLE IF NOT EXISTS `estados` (
  `id_estado` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(100) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `estados`
--

INSERT INTO `estados` (`id_estado`, `estado`) VALUES
(1, 'Carabobo'),
(2, 'Aragua');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipios`
--

DROP TABLE IF EXISTS `municipios`;
CREATE TABLE IF NOT EXISTS `municipios` (
  `id_municipio` int NOT NULL AUTO_INCREMENT,
  `id_estado` int NOT NULL,
  `municipio` varchar(100) NOT NULL,
  PRIMARY KEY (`id_municipio`),
  KEY `id_estado` (`id_estado`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `municipios`
--

INSERT INTO `municipios` (`id_municipio`, `id_estado`, `municipio`) VALUES
(1, 1, 'Valencia'),
(2, 1, 'Bejuma'),
(3, 2, 'Maracay'),
(4, 2, 'Turmero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parroquias`
--

DROP TABLE IF EXISTS `parroquias`;
CREATE TABLE IF NOT EXISTS `parroquias` (
  `id_parroquia` int NOT NULL AUTO_INCREMENT,
  `id_municipio` int NOT NULL,
  `parroquia` varchar(100) NOT NULL,
  PRIMARY KEY (`id_parroquia`),
  KEY `id_municipio` (`id_municipio`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `parroquias`
--

INSERT INTO `parroquias` (`id_parroquia`, `id_municipio`, `parroquia`) VALUES
(1, 1, 'Candelaria'),
(2, 1, 'Miguel Peña'),
(3, 2, 'Bejuma Centro'),
(4, 3, 'Maracay Centro'),
(5, 4, 'Turmero Centro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitantes`
--

DROP TABLE IF EXISTS `solicitantes`;
CREATE TABLE IF NOT EXISTS `solicitantes` (
  `id_solicitante` int NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `sexo` enum('MASCULINO','FEMENINO') NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_solicitante`),
  UNIQUE KEY `cedula` (`cedula`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `solicitantes`
--

INSERT INTO `solicitantes` (`id_solicitante`, `cedula`, `nombre`, `apellido`, `fecha_nacimiento`, `sexo`, `telefono`) VALUES
(1, '18757735', 'Gabriel de Jesus', 'Carrero Brito', '0000-00-00', 'MASCULINO', '04125698932');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubch`
--

DROP TABLE IF EXISTS `ubch`;
CREATE TABLE IF NOT EXISTS `ubch` (
  `id_ubch` int NOT NULL AUTO_INCREMENT,
  `id_comunidad` int NOT NULL,
  `nombre_ubch` varchar(100) NOT NULL,
  PRIMARY KEY (`id_ubch`),
  KEY `id_comunidad` (`id_comunidad`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `ubch`
--

INSERT INTO `ubch` (`id_ubch`, `id_comunidad`, `nombre_ubch`) VALUES
(1, 1, 'UBCH Candelaria Norte 1'),
(2, 1, 'UBCH Candelaria Norte 2'),
(3, 2, 'UBCH Candelaria Sur'),
(4, 3, 'UBCH Peña Alta'),
(5, 4, 'UBCH Peña Baja'),
(6, 5, 'UBCH Bejuma Central'),
(7, 6, 'UBCH Maracay Centro 1'),
(8, 7, 'UBCH Turmero Centro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `clave` char(32) NOT NULL,
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo',
  `fecha_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `clave`, `estado`, `fecha_registro`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'activo', '2025-06-02 15:42:05');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
