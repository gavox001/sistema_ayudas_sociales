<?php 
require_once '../includes/conexion.php'; 

$error = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $conexion->beginTransaction();

        // Datos del solicitante
        $cedula_solicitante = $_POST['solicitante_cedula'];
        $nombre_solicitante = $_POST['solicitante_nombreUno'] . ' ' . $_POST['solicitante_nombreDos'];
        $apellido_solicitante = $_POST['solicitante_apellidoUno'] . ' ' . $_POST['solicitante_apellidoDos'];
        $telefono_solicitante = $_POST['solicitante_telefono'];

        // Datos del beneficiario
        $cedula_beneficiario = $_POST['beneficiario_cedula'];
        $nombre_beneficiario = $_POST['beneficiario_nombreUno'] . ' ' . $_POST['beneficiario_nombreDos'];
        $apellido_beneficiario = $_POST['beneficiario_apellidoUno'] . ' ' . $_POST['beneficiario_apellidoDos'];

        // Validaciones
        if (empty($cedula_solicitante) || empty($cedula_beneficiario)) {
            throw new Exception("La cédula del solicitante y beneficiario es obligatoria.");
        }

        // Verificar si el solicitante ya existe
        $stmt = $conexion->prepare("SELECT id_solicitante FROM solicitantes WHERE cedula = ?");
        $stmt->execute([$cedula_solicitante]);
        if ($stmt->fetch()) {
            throw new Exception("La cédula del solicitante ya está registrada.");
        }

        // Insertar solicitante
        $stmt = $conexion->prepare("INSERT INTO solicitantes (cedula, nombre, apellido, telefono) VALUES (?, ?, ?, ?)");
        $stmt->execute([$cedula_solicitante, $nombre_solicitante, $apellido_solicitante, $telefono_solicitante]);
        $id_solicitante = $conexion->lastInsertId();

        // Insertar beneficiario
        $stmt = $conexion->prepare("INSERT INTO beneficiarios (cedula, nombre, apellido) VALUES (?, ?, ?)");
        $stmt->execute([$cedula_beneficiario, $nombre_beneficiario, $apellido_beneficiario]);
        $id_beneficiario = $conexion->lastInsertId();

        // Insertar caso
        $stmt = $conexion->prepare("INSERT INTO casos (id_solicitante, id_beneficiario, estatus_caso, tipo_solicitud) VALUES (?, ?, 'PENDIENTE', 'NO DEFINIDO')");
        $stmt->execute([$id_solicitante, $id_beneficiario]);

        if ($stmt->rowCount() > 0) {
            $conexion->commit();
            header("Location: formulario_solicitud.php");
            exit();
        } else {
            throw new Exception("No se pudo guardar los datos.");
        }
    } catch (PDOException $e) {
        $conexion->rollBack();
        $error = "Error en la base de datos: " . $e->getMessage();
    } catch (Exception $e) {
        $conexion->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <br><br>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    <form id="formRegistro" action="" method="post">
                        <!-- Campos del formulario -->
                        <h3 class="section-title">Datos del Solicitante</h3>
                        <div class="row">
                            <div class="col">
                                <label>Cédula</label>
                                <input type="text" name="solicitante_cedula" required>
                            </div>
                            <div class="col">
                                <label>Primer Nombre</label>
                                <input type="text" name="solicitante_nombreUno" required>
                            </div>
                            <div class="col">
                                <label>Segundo Nombre</label>
                                <input type="text" name="solicitante_nombreDos" required>
                            </div>
                            <div class="col">
                                <label>Primer Apellido</label>
                                <input type="text" name="solicitante_apellidoUno" required>
                            </div>
                            <div class="col">
                                <label>Segundo Apellido</label>
                                <input type="text" name="solicitante_apellidoDos" required>
                            </div>
                            <div class="col">
                                <label>Fecha de Nacimiento</label>
                                <input type="date" name="solicitante_nacimiento">
                            </div>
                            <div class="col">
                                <label>Sexo</label>
                                <select name="solicitante_sexo">
                                    <option value="">Seleccione</option>
                                    <option value="MASCULINO">Masculino</option>
                                    <option value="FEMENINO">Femenino</option>
                                </select>
                            </div>
                            <div class="col">
                                <label>Teléfono</label>
                                <input type="text" name="solicitante_telefono" required>
                            </div>
                        </div>
                        <h3 class="section-title">Datos del Beneficiario</h3>
                        <div class="row">
                            <div class="col">
                                <label>Cédula</label>
                                <input type="text" name="beneficiario_cedula" required>
                            </div>
                            <div class="col">
                                <label>Primer Nombre</label>
                                <input type="text" name="beneficiario_nombreUno" required>
                            </div>
                            <div class="col">
                                <label>Segundo Nombre</label>
                                <input type="text" name="beneficiario_nombreDos" required>
                            </div>
                            <div class="col">
                                <label>Primer Apellido</label>
                                <input type="text" name="beneficiario_apellidoUno" required>
                            </div>
                            <div class="col">
                                <label>Segundo Apellido</label>
                                <input type="text" name="beneficiario_apellidoDos" required>
                            </div>
                            <div class="col">
                                <label>Fecha de Nacimiento</label>
                                <input type="date" name="beneficiario_nacimiento">
                            </div>
                            <div class="col">
                                <label>Sexo</label>
                                <select name="beneficiario_sexo">
                                    <option value="">Seleccione</option>
                                    <option value="MASCULINO">Masculino</option>
                                    <option value="FEMENINO">Femenino</option>
                                </select>
                            </div>
                        </div>
                        <br><br>
                        <button type="submit" class="btn btn-sm btn-success">Continuar la Solicitud</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>