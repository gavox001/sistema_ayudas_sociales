<?php include '../includes/header.php'; ?>

<div class="container">
    <br>
    <br>
    <div class="row">
        <div class="col-md-12 d-flex justify-content-center">
            <div class="card">
                <div class="card-body">
                    <form action="consultar_casos.php" method="get">
                        <div class="row">
                            <h1 class="section-title">Consultar Casos</h1>

                            <div class="col">
                                <label for="cedula">C.I (Solic o Benef):</label>
                                <input type="text" name="cedula" id="cedula" class="form-control" value="<?php echo htmlspecialchars(isset($_GET['cedula']) ? $_GET['cedula'] : ''); ?>">
                            </div>
                            <div class="col">
                                <label for="estatus_caso">Estatus del Caso:</label>
                                <select name="estatus_caso" id="estatus_caso" class="form-control">
                                    <option value="">Seleccione</option>
                                    <option value="SIN ATENDER" <?php echo isset($_GET['estatus_caso']) && $_GET['estatus_caso'] == "SIN ATENDER" ? "selected" : ""; ?>>Sin Atender</option>
                                    <option value="ATENDIDO" <?php echo isset($_GET['estatus_caso']) && $_GET['estatus_caso'] == "ATENDIDO" ? "selected" : ""; ?>>Atendido</option>
                                    <option value="EN PROCESO" <?php echo isset($_GET['estatus_caso']) && $_GET['estatus_caso'] == "EN PROCESO" ? "selected" : ""; ?>>En Proceso</option>
                                </select>
                            </div>
                            <div class="col">
                                <label for="estatus407">Estatus 407:</label>
                                <select name="estatus407" id="estatus407" class="form-control">
                                    <option value="">Seleccione</option>
                                    <option value="407" <?php echo isset($_GET['estatus407']) && $_GET['estatus407'] == "407" ? "selected" : ""; ?>>407</option>
                                    <option value="NO 407" <?php echo isset($_GET['estatus407']) && $_GET['estatus407'] == "NO 407" ? "selected" : ""; ?>>No 407</option>
                                </select>
                            </div>
                            <div class="col">
                                <label for="tipo_solicitud">Tipo de Solicitud:</label>
                                <select name="tipo_solicitud" id="tipo_solicitud" class="form-control">
                                    <option value="">Seleccione</option>
                                    <option value="INFRAESTRUCTURA" <?php echo isset($_GET['tipo_solicitud']) && $_GET['tipo_solicitud'] == "INFRAESTRUCTURA" ? "selected" : ""; ?>>Infraestructura</option>
                                    <option value="SOCIAL" <?php echo isset($_GET['tipo_solicitud']) && $_GET['tipo_solicitud'] == "SOCIAL" ? "selected" : ""; ?>>Social</option>
                                    <option value="TECNICO" <?php echo isset($_GET['tipo_solicitud']) && $_GET['tipo_solicitud'] == "TECNICO" ? "selected" : ""; ?>>Técnico</option>
                                    <option value="MEDICAMENTO" <?php echo isset($_GET['tipo_solicitud']) && $_GET['tipo_solicitud'] == "MEDICAMENTO" ? "selected" : ""; ?>>Medicamento</option>
                                    <option value="SALUD" <?php echo isset($_GET['tipo_solicitud']) && $_GET['tipo_solicitud'] == "SALUD" ? "selected" : ""; ?>>Salud</option>
                                    <option value="OTROS" <?php echo isset($_GET['tipo_solicitud']) && $_GET['tipo_solicitud'] == "OTROS" ? "selected" : ""; ?>>Otros</option>
                                </select>
                            </div>
                            <div class="col">
                                <label for="tipo_caso">Tipo de Caso:</label>
                                <select name="tipo_caso" id="tipo_caso" class="form-control">
                                    <option value="">Seleccione</option>
                                    <option value="CARTA" <?php echo isset($_GET['tipo_caso']) && $_GET['tipo_caso'] == "CARTA" ? "selected" : ""; ?>>Carta</option>
                                    <option value="AGENDA" <?php echo isset($_GET['tipo_caso']) && $_GET['tipo_caso'] == "AGENDA" ? "selected" : ""; ?>>Agenda</option>
                                    <option value="OFICIO" <?php echo isset($_GET['tipo_caso']) && $_GET['tipo_caso'] == "OFICIO" ? "selected" : ""; ?>>Oficio</option>
                                </select>
                            </div>
                            <div class="col">
                                <br>
                                <button type="submit" class="btn btn-primary">Buscar</button>
                            </div>
                        </div>
                    </form>
                    
                    <br>
                    
                    <?php
                    // Mostrar resultados si hay parámetros de búsqueda
                    if (
                        $_SERVER['REQUEST_METHOD'] === 'GET' &&
                        (
                            !empty($_GET['estatus407']) ||
                            !empty($_GET['tipo_solicitud']) ||
                            !empty($_GET['tipo_caso']) ||
                            !empty($_GET['cedula']) ||
                            !empty($_GET['estatus_caso'])
                        )
                    ) {
                        $resultados = include 'buscar_casos.php';
                        
                        if (!empty($resultados)) {
                            echo '<div class="table-responsive">';
                            echo '<table class="table table-hover">';
                            echo '<thead><tr>
                                    <th>ID Caso</th>
                                    <th>Cédula Solicitante</th>
                                    <th>Nombre Solicitante</th>
                                    <th>Apellido Solicitante</th>
                                    <th>Cédula Beneficiario</th>
                                    <th>Nombre Beneficiario</th>
                                    <th>Apellido Beneficiario</th>
                                    <th>Estatus del Caso</th>
                                    <th>Estatus 407</th>
                                    <th>Tipo de Solicitud</th>
                                    <th>Tipo de Caso</th>
                                    <th>Fecha Registro</th>
                                    <th>Acciones</th>
                                  </tr></thead>';
                            echo '<tbody>';
                            
                            foreach ($resultados as $caso) {
                                echo '<tr>';
                                echo '<td>' . htmlspecialchars($caso['id_caso'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['cedula_solicitante'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['nombre_solicitante'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['apellido_solicitante'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['cedula_beneficiario'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['nombre_beneficiario'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['apellido_beneficiario'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['estatus_caso'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['estatus407'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['tipo_solicitud'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['tipo_caso'] ?? '') . '</td>';
                                echo '<td>' . htmlspecialchars($caso['fecha_registro'] ?? '') . '</td>';
                                echo '<td>
                                    <button type="button" class="btn btn-sm btn-warning edit-btn" data-id="' . htmlspecialchars($caso['id_caso']) . '">
                                        Editar
                                    </button>
                                  </td>';
                                echo '</tr>';
                            }
                            echo '</tbody>';
                            echo '</table>';
                            echo '</div>';
                            
                            // Formulario modal para edición
                            echo '
                            <div class="modal fade" id="editModal" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Editar Caso</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form id="editForm" action="actualizar_casos.php" method="post">
                                                <input type="hidden" name="id_caso" id="editId">
                                                
                                                <div class="mb-3">
                                                    <label for="editEstatusCaso" class="form-label">Estatus del Caso:</label>
                                                    <select name="estatus_caso" id="editEstatusCaso" class="form-control">
                                                        <option value="SIN ATENDER">Sin Atender</option>
                                                        <option value="ATENDIDO">Atendido</option>
                                                        <option value="EN PROCESO">En Proceso</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="editEstatus407" class="form-label">Estatus 407:</label>
                                                    <select name="estatus407" id="editEstatus407" class="form-control">
                                                        <option value="407">407</option>
                                                        <option value="NO 407">No 407</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="editTipoSolicitud" class="form-label">Tipo de Solicitud:</label>
                                                    <select name="tipo_solicitud" id="editTipoSolicitud" class="form-control">
                                                        <option value="INFRAESTRUCTURA">Infraestructura</option>
                                                        <option value="SOCIAL">Social</option>
                                                        <option value="TECNICO">Técnico</option>
                                                        <option value="MEDICAMENTO">Medicamento</option>
                                                        <option value="SALUD">Salud</option>
                                                        <option value="OTROS">Otros</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="editTipoCaso" class="form-label">Tipo de Caso:</label>
                                                    <select name="tipo_caso" id="editTipoCaso" class="form-control">
                                                        <option value="CARTA">Carta</option>
                                                        <option value="AGENDA">Agenda</option>
                                                        <option value="OFICIO">Oficio</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                                <button type="submit" class="btn btn-primary">Actualizar</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            ';
                            
                            // Script para manejar el modal de edición
                            echo '
                            <script>
                                document.addEventListener("DOMContentLoaded", function() {
                                    const editButtons = document.querySelectorAll(".edit-btn");
                                    const modal = new bootstrap.Modal(document.getElementById("editModal"));
                                    
                                    editButtons.forEach(button => {
                                        button.addEventListener("click", function() {
                                            const casoId = this.getAttribute("data-id");
                                            document.getElementById("editId").value = casoId;
                                            
                                            // Aquí podrías hacer una llamada AJAX para cargar los datos del caso
                                            // y prellenar el formulario del modal
                                            
                                            modal.show();
                                        });
                                    });
                                });
                            </script>
                            ';
                        } else {
                            echo '<p>No se encontraron resultados.</p>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>