<?php
// Conectar a la base de datos
require_once '../includes/conexion.php';

// Función para verificar si una persona está registrada
function verificarRegistro($pdo, $tabla, $cedula) {
    $stmt = $pdo->prepare("SELECT * FROM $tabla WHERE cedula = :cedula");
    $stmt->execute(['cedula' => $cedula]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Función para registrar una nueva persona
function registrarPersona($pdo, $tabla, $datos) {
    $columnas = implode(", ", array_keys($datos));
    $valores = ":" . implode(", :", array_keys($datos));
    $stmt = $pdo->prepare("INSERT INTO $tabla ($columnas) VALUES ($valores)");
    $stmt->execute($datos);
}

// Procesar datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Datos del solicitante
    $solicitante = [
        'cedula' => $_POST['solicitante_cedula'],
        'primer_nombre' => $_POST['solicitante_nombreUno'],
        'segundo_nombre' => $_POST['solicitante_nombreDos'],
        'primer_apellido' => $_POST['solicitante_apellidoUno'],
        'segundo_apellido' => $_POST['solicitante_apellidoDos'],
        'fecha_nacimiento' => $_POST['solicitante_nacimiento'],
        'sexo' => $_POST['solicitante_sexo'],
        'telefono' => $_POST['solicitante_telefono']
    ];

    // Verificar y registrar solicitante
    if (!verificarRegistro($pdo, 'solicitantes', $solicitante['cedula'])) {
        registrarPersona($pdo, 'solicitantes', $solicitante);
    }

    // Datos del beneficiario
    $beneficiario = [
        'cedula' => $_POST['beneficiario_cedula'],
        'primer_nombre' => $_POST['beneficiario_nombreUno'],
        'segundo_nombre' => $_POST['beneficiario_nombreDos'],
        'primer_apellido' => $_POST['beneficiario_apellidoUno'],
        'segundo_apellido' => $_POST['beneficiario_apellidoDos'],
        'fecha_nacimiento' => $_POST['beneficiario_nacimiento'],
        'sexo' => $_POST['beneficiario_sexo']
    ];

    // Verificar y registrar beneficiario
    if (!verificarRegistro($pdo, 'beneficiarios', $beneficiario['cedula'])) {
        registrarPersona($pdo, 'beneficiarios', $beneficiario);
    }

    echo "Registro completado con éxito.";
} else {
    echo "Método de solicitud no permitido.";
}
?>
