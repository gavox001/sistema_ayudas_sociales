<?php include '../includes/header.php'; ?>

<div class="container">
<br>
<br>
    <div class="row">
        
        <div class="col-md-12 d-flex justify-content-center">

            <div class="card">
                <div class="card-body">
                    <form id="formSolicitud" action="" method="post" enctype="multipart/form-data">
                        <h3 class="section-title">Datos de la Solicitud</h3>


                        <div class="row">

                            <div class="col">
                                <label>Estado</label>
                                <select name="estado" id="estado" required>
                                    <option value="">Seleccione</option>

                                </select>
                            </div>

                            <div class="col">
                                <label>Municipio</label>
                                <select name="municipio" id="municipio" required>
                                    <option value="">Seleccione</option>
                                </select>
                            </div>

                            <div class="col">
                                <label>Parroquia</label>
                                <select name="parroquia" id="parroquia" required>
                                    <option value="">Seleccione</option>
                                </select>
                            </div>

                            <div class="col">
                                <label>Comunidad</label>
                                <select name="comunidad" id="comunidad">
                                    <option value="">Seleccione</option>
                                </select>
                            </div>
                            <div class="col">
                                <label>UBCH</label>
                                <select name="ubch" id="ubch" required>
                                    <option value="">Seleccione</option>

                                </select>
                            </div>

                        </div>





                        <div class="solicitud">
                            <div class="row">



                                <div class="col"><label>Institución</label><input type="text" name="institucion"></div>

                                <div class="col"><label>Tipo de Solicitud</label>
                                    <select name="tipo_solicitud" onchange="mostrarCamposAdicionales(this)" required>
                                        <option value="">Seleccione</option>
                                        <option value="SALUD">Salud</option>
                                        <option value="MEDICAMENTO">Medicamento</option>
                                        <option value="INFRAESTRUCTURA">Infraestructura</option>
                                        <option value="SOCIAL">Social</option>
                                        <option value="TECNICO">Técnico</option>
                                        <option value="OTROS">Otros</option>
                                    </select>
                                </div>

                                <div class="col">
                                    <label>Estatus</label>
                                    <select name="estatus" required>
                                        <option value="">Seleccione</option>
                                        <option value="ATENDIDO">ATENDIDO</option>
                                        <option value="SIN ATENDER">SIN ATENDER</option>
                                        <option value="EN PROCESO">EN PROCESO</option>
                                    </select>
                                </div>




                            </div>

                            <div class="row">
                                <div class="col">
                                    <label>Código de Oficio</label>
                                    <div class="codigo-oficio">
                                        <select name="codigo_oficio_prefijo" required>
                                            <option value="">Seleccione</option>
                                            <option value="GGP">GGP</option>
                                            <option value="PP">PP</option>
                                            <option value="GG">GG</option>
                                        </select>
                                        <input type="text" name="codigo_oficio_numero" placeholder="001" maxlength="10" required>
                                        <input type="text" name="codigo_oficio_anio" placeholder="2025" maxlength="4" required>

                                    </div>

                                </div>



                                <div class="col">

                                    <label>Tipo de Caso</label>
                                    <select name="tipo_caso" required>
                                        <option value="">Seleccione</option>
                                        <option value="CARTA">CARTA</option>
                                        <option value="AGENDA">AGENDA</option>
                                        <option value="OFICIO">OFICIO</option>
                                    </select>

                                </div>

                                <div class="col">
                                    <label>Nivel de Caso</label>
                                    <select name="nivel_caso" required>
                                        <option value="">Seleccione</option>
                                        <option value="PRIORIDAD">PRIORIDAD</option>
                                        <option value="PRINCIPAL">PRINCIPAL</option>
                                        <option value="COMUN">COMUN</option>
                                    </select>


                                </div>


                            </div>

                            <div class="row">

                                <div class="col"><label>Descripción de la Solicitud</label><textarea name="descripcion_solicitud" rows="3"></textarea></div>

                                <div class="col">

                                    <label>Imagen del caso</label>
                                    <div id="drop_zone">
                                        Arrastra una imagen aquí o haz clic para seleccionarla
                                    </div>
                                    <input type="file" name="imagenes[]" id="file_input" style="display:none;" accept="image/*" multiple>
                                    <div id="preview_container"></div>

                                </div>



                            </div>
                            <!-- Campos adicionales para Infraestructura -->
                            <div class="infraestructura-fields" id="infraestructura-fields" style="display:none;">
                                <h4 style="color:#0a0638;">Campos adicionales para Infraestructura</h4>

                                <div class="row">
                                    <div class="col">
                                        <label>Tipo de Especificación</label>
                                        <input type="text" name="tipo_especificacion" class="form-control">
                                    </div>
                                    <div class="col">
                                        <label>Título</label>
                                        <textarea name="titulo_Esp" class="form-control"></textarea>
                                    </div>
                                    <div class="col">
                                        <label>Descripción General</label>
                                        <input type="text" name="descripcion_general" class="form-control">
                                    </div>
                                </div>

                                <hr>
                                <h5>Detalle de Ítems</h5>
                                <table class="table" id="tabla-detalles">
                                    <thead>
                                        <tr>
                                            <th>Nombre Ítem</th>
                                            <th>Cantidad</th>
                                            <th>Unidad</th>
                                            <th>Costo Estimado</th>
                                            <th>Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody id="detalle-body">
                                        <!-- Filas dinámicas -->
                                    </tbody>
                                </table>
                                <input type="hidden" name="detalle_items" id="detalle-items-input">
                                <script>
                                    function agregarFila() {
                                        const tbody = document.getElementById('detalle-body');
                                        const row = document.createElement('tr');

                                        row.innerHTML = `
                        <td><input type="text" name="nombre_item[]" class="form-control" required></td>
                        <td><input type="number" name="cantidad[]" class="form-control" required></td>
                        <td><input type="text" name="unidad[]" class="form-control" required></td>
                        <td><input type="number" name="costo_estimado[]" class="form-control" required></td>
                        <td><button type="button" class="btn btn-danger btn-sm" onclick="eliminarFila(this)">Eliminar</button></td>
                    `;

                                        tbody.appendChild(row);
                                    }

                                    function eliminarFila(button) {
                                        const row = button.closest('tr');
                                        row.remove();
                                    }
                                </script>
                                <button type="button" class="btn btn-sm btn-success" onclick="agregarFila()">Agregar Ítem</button>
                            </div>



                            <!-- Campos adicionales para Medicamento -->
                            <div class="medicamento-fields" id="medicamento-fields" style="display:none;">
                                <h4 style="color:#0a0638;">Campos adicionales para Medicamento</h4>
                                <div class="row">
                                    <div class="col"><label>Nombre del Medicamento</label><input type="text" name="nombre_medicamento"></div>
                                    <div class="col"><label>Presentación</label><input type="text" name="presentacion"></div>
                                    <div class="col"><label>Cantidad Solicitada</label><input type="number" name="cantidad_medicamento"></div>
                                </div>
                            </div>
                            <button type="submit" class="btn-submit">Registrar Caso</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('tipoSolicitud').addEventListener('change', function() {
        var detallesInfraestructura = document.getElementById('detallesInfraestructura');
        if (this.value === 'infraestructura') {
            detallesInfraestructura.style.display = 'block';
        } else {
            detallesInfraestructura.style.display = 'none';
        }
    });
</script>

<?php include '../includes/footer.php'; ?>