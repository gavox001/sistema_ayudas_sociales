<<?php
require_once '../includes/conexion.php';
require_once '../includes/header.php';

// Verificar si se envió el formulario de actualización
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_caso'])) {
    $id_caso = $_POST['id_caso'];
    $estatus_caso = $_POST['estatus_caso'];
    $estatus407 = $_POST['estatus407'];
    $tipo_solicitud = $_POST['tipo_solicitud'];
    $tipo_caso = $_POST['tipo_caso'];
    
    // Preparar la consulta de actualización
    $query = "
        UPDATE casos 
        SET 
            estatus_caso = :estatus_caso,
            estatus407 = :estatus407,
            tipo_solicitud = :tipo_solicitud,
            tipo_caso = :tipo_caso,
            fecha_actualizacion = NOW()
        WHERE id_caso = :id_caso
    ";
    
    try {
        $stmt = $conexion->prepare($query);
        $stmt->execute([
            'estatus_caso' => $estatus_caso,
            'estatus407' => $estatus407,
            'tipo_solicitud' => $tipo_solicitud,
            'tipo_caso' => $tipo_caso,
            'id_caso' => $id_caso
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo '<div class="alert alert-success" role="alert">
                    El caso ha sido actualizado exitosamente.
                  </div>';
        } else {
            echo '<div class="alert alert-warning" role="alert">
                    No se pudo actualizar el caso. Por favor, inténtelo de nuevo.
                  </div>';
        }
        
    } catch(PDOException $e) {
        error_log("Error actualizando el caso: " . $e->getMessage());
        echo '<div class="alert alert-danger" role="alert">
                Ocurrió un error al actualizar el caso. Por favor, inténtelo de nuevo.
              </div>';
    }
} else {
    echo '<div class="alert alert-danger" role="alert">
            Acceso no válido.
          </div>';
}

// Redirigir de regreso a la página de consulta después de 2 segundos
echo '
    <script>
        setTimeout(function() {
            window.location.href = "consultar_casos.php";
        }, 2000);
    </script>
';

require_once '../includes/footer.php';
?>