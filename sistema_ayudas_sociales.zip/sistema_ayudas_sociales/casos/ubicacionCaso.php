<?php
require '../includes/conexion.php'; // Asegúrate que la ruta sea correcta

header('Content-Type: application/json');

$tipo = $_GET['tipo'] ?? '';
$resultado = [];

try {
    switch ($tipo) {
        case 'estado':
            $stmt = $conexion->query("SELECT id_estado AS id, estado AS nombre FROM estados");
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'municipio':
            $id = intval($_GET['id_estado'] ?? 0);
            $stmt = $conexion->prepare("SELECT id_municipio AS id, municipio AS nombre FROM municipios WHERE id_estado = ?");
            $stmt->execute([$id]);
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'parroquia':
            $id = intval($_GET['id_municipio'] ?? 0);
            $stmt = $conexion->prepare("SELECT id_parroquia AS id, parroquia AS nombre FROM parroquias WHERE id_municipio = ?");
            $stmt->execute([$id]);
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'ubch':
            $id = intval($_GET['id_parroquia'] ?? 0);
            $stmt = $conexion->prepare("SELECT id_ubch AS id, nombre_ubch AS nombre FROM ubch WHERE id_comunidad = ?");
            $stmt->execute([$id]);
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'comunidad':
            $id = intval($_GET['id_parroquia'] ?? 0);
            $stmt = $conexion->prepare("SELECT id_comunidad AS id, nombre_comun AS nombre FROM comunidades WHERE id_parroquia = ?");
            $stmt->execute([$id]);
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;

        default:
            $resultado = ['error' => 'Tipo no válido'];
    }

} catch (PDOException $e) {
    $resultado = ['error' => $e->getMessage()];
}

echo json_encode($resultado);
?>
