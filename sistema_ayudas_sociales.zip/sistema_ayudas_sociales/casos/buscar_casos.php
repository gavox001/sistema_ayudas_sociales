<?php
require_once '../includes/conexion.php';

// Obtener parámetros de búsqueda
$cedula = isset($_GET['cedula']) ? $_GET['cedula'] : '';
$estatus_caso = isset($_GET['estatus_caso']) ? $_GET['estatus_caso'] : '';
$estatus407 = isset($_GET['estatus407']) ? $_GET['estatus407'] : '';
$tipo_solicitud = isset($_GET['tipo_solicitud']) ? $_GET['tipo_solicitud'] : '';
$tipo_caso = isset($_GET['tipo_caso']) ? $_GET['tipo_caso'] : '';

// Construir consulta
// En buscar_casos.php

// ...

// Construir consulta
$query = "
    SELECT 
        casos.id_caso,
        COALESCE(solicitantes.cedula, '') AS cedula_solicitante,
        COALESCE(solicitantes.nombre, '') AS nombre_solicitante,
        COALESCE(solicitantes.apellido, '') AS apellido_solicitante,
        COALESCE(beneficiarios.cedula, '') AS cedula_beneficiario,
        COALESCE(beneficiarios.nombre, '') AS nombre_beneficiario,
        COALESCE(beneficiarios.apellido, '') AS apellido_beneficiario,
        COALESCE(casos.estatus_caso, '') AS estatus_caso,
        COALESCE(casos.estatus407, '') AS estatus407,
        COALESCE(casos.tipo_solicitud, '') AS tipo_solicitud,
        COALESCE(casos.tipo_caso, '') AS tipo_caso,
        COALESCE(casos.fecha_solicitud, '') AS fecha_solicitud
    FROM 
        casos
    LEFT JOIN 
        solicitantes ON casos.id_solicitante = solicitantes.id_solicitante
    LEFT JOIN 
        beneficiarios ON casos.id_beneficiario = beneficiarios.id_beneficiario
    WHERE 1=1
";

// ...

// Si buscas por estatus407 pero en la base de datos hay valores NULL, ajusta la consulta
if ($estatus407 !== '') {
    $query .= " AND (TRIM(casos.estatus407) = :estatus407 OR (casos.estatus407 IS NULL AND :estatus407 = ''))";
    $params['estatus407'] = $estatus407;
}
$params = [];

if ($cedula !== '') {
    $query .= " AND (solicitantes.cedula = :cedula OR beneficiarios.cedula = :cedula)";
    $params['cedula'] = $cedula;
}

if ($estatus_caso !== '') {
    $query .= " AND casos.estatus_caso = :estatus_caso";
    $params['estatus_caso'] = $estatus_caso;
}

if ($estatus407 !== '') {
    $query .= " AND TRIM(casos.estatus407) = :estatus407";
    $params['estatus407'] = $estatus407;
}

if ($tipo_solicitud !== '') {
    $query .= " AND casos.tipo_solicitud = :tipo_solicitud";
    $params['tipo_solicitud'] = $tipo_solicitud;
}

if ($tipo_caso !== '') {
    $query .= " AND casos.tipo_caso = :tipo_caso";
    $params['tipo_caso'] = $tipo_caso;
}

// Agregar ordenamiento para mejor visualización
$query .= " ORDER BY casos.fecha_registro DESC";

try {
    // Ejecutar consulta
    $stmt = $conexion->prepare($query);
    $stmt->execute($params);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Retornar resultados
    return $resultados;
} catch(PDOException $e) {
    // Manejo de errores
    error_log("Error en la consulta: " . $e->getMessage());
    return [];
}
?>