<?php include('../includes/conexion.php'); ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>

    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/personalizados/styleLogin.css">

</head>

<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <!-- Columna izquierda: Imagen -->
            <div class="col-md-7 d-none d-md-block p-0">
                <div class="login-image h-100"></div>
            </div>
            <!-- Columna derecha: Login -->
            <div class="col-md-5 d-flex align-items-center justify-content-center bg-dark-blue">
                <div class="w-75">
                    <h1 class="text-white text-center mb-4 modern-underline-title">
                        <span class="title-text">Sistema de Ayudas Sociales</span>
                        <span class="underline"></span>
                    </h1>
                    <h4 class="text-white text-center mb-4">Bienvenido(a)</h4>
                    <form action="validarUsuario.php" method="post">
                        <div class="mb-3">
                            <label class="form-label text-white" for="usuario">Usuario</label>
                            <input class="form-control" type="text" id="usuario" name="usuario" placeholder="Ingresa tu usuario" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-white" for="clave">Contraseña</label>
                            <input class="form-control" type="password" id="clave" name="clave" placeholder="Ingresa tu contraseña" required>
                        </div>
                        <div class="d-grid">
                            <button class="btn btn-success" type="submit">Iniciar Sesión</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>

</html>