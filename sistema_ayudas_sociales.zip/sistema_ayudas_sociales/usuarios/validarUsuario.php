<?php
session_start();
include('../includes/conexion.php');

// Recoge los datos del formulario
$usuario = $_POST['usuario'];
$clave = md5(string: $_POST['clave']); // Aplica MD5 a la clave ingresada

// Consulta para validar usuario activo
$sql = "SELECT * FROM usuarios WHERE usuario = ? AND clave = ? AND estado = 'activo'";
$stmt = $conexion->prepare($sql);
$stmt->bindValue(1, $usuario, PDO::PARAM_STR);
$stmt->bindValue(2, $clave, PDO::PARAM_STR);
$stmt->execute();
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row) {
    // Usuario autenticado: guarda datos en sesión
    $_SESSION['id_usuario'] = $row['id_usuario'];
    $_SESSION['usuario'] = $row['usuario'];
    $_SESSION['rol'] = $row['rol'];

    // REGISTRO EN BITÁCORA
    $id_usuario = $row['id_usuario'];
    $accion = "Inicio de sesión";
    $ip_usuario = $_SERVER['REMOTE_ADDR'];
    $sql_bitacora = "INSERT INTO bitacora (id_usuario, accion, fecha, ip_usuario) VALUES (?, ?, NOW(), ?)";
    $stmt_bitacora = $conexion->prepare(query: $sql_bitacora);
    $stmt_bitacora->bindParam(param: 1, var: $id_usuario, type: PDO::PARAM_INT);
    $stmt_bitacora->bindParam(param: 2, var: $accion, type: PDO::PARAM_STR);
    $stmt_bitacora->bindParam(param: 3, var: $ip_usuario, type: PDO::PARAM_STR);
    $stmt_bitacora->execute();

    // redirigir a archivo dashboard.php
    header(header: "Location: ../dashboard/dashboard.php");
  
    exit();
} else {
    // Login fallido
    header(header: "Location: login.php?error=1");
    exit();
}
?>