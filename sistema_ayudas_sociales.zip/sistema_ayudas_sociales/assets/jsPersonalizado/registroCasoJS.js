
document.addEventListener('DOMContentLoaded', function () {
    const dropZone = document.getElementById('drop_zone');
    const fileInput = document.getElementById('file_input');
    const previewContainer = document.getElementById('preview_container');

    let selectedFiles = [];

    // Mostrar vistas previas de imágenes
    function updatePreviews() {
        previewContainer.innerHTML = '';

        selectedFiles.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = function (e) {
                const preview = document.createElement('div');
                preview.style.margin = '10px';
                preview.style.display = 'inline-block';
                preview.innerHTML = `
                    <img src="${e.target.result}" style="max-width: 150px; max-height: 150px; display: block; margin-bottom: 5px;" />
                    <button type="button" style="background: red; color: white; border: none; padding: 5px 10px; cursor: pointer;">Eliminar</button>
                `;
                preview.querySelector('button').addEventListener('click', () => {
                    selectedFiles.splice(index, 1);
                    updatePreviews();
                });
                previewContainer.appendChild(preview);
            };
            reader.readAsDataURL(file);
        });

        dropZone.innerHTML = selectedFiles.length > 0
            ? `${selectedFiles.length} imagen(es) seleccionada(s)`
            : "Arrastra una imagen aquí o haz clic para seleccionarla";

        updateFileInput();
    }

    // Actualizar el input de archivos con los seleccionados
    function updateFileInput() {
        const dataTransfer = new DataTransfer();
        selectedFiles.forEach(file => dataTransfer.items.add(file));
        fileInput.files = dataTransfer.files;
    }

    // Eventos
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = 'green';
        dropZone.style.background = '#f0f0f0';
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.style.borderColor = '#aaa';
        dropZone.style.background = 'white';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '#aaa';
        dropZone.style.background = 'white';

        const files = Array.from(e.dataTransfer.files);
        files.forEach(file => {
            if (file.type.startsWith('image/')) {
                selectedFiles.push(file);
            }
        });
        updatePreviews();
    });

    fileInput.addEventListener('change', () => {
        const files = Array.from(fileInput.files);
        files.forEach(file => {
            if (file.type.startsWith('image/')) {
                selectedFiles.push(file);
            }
        });
        updatePreviews();
    });
});

//scrip de campos adicionesles

function mostrarCamposAdicionales(select) {
    var infra = document.getElementById('infraestructura-fields');
    var medi = document.getElementById('medicamento-fields');
    infra.style.display = 'none';
    medi.style.display = 'none';
    if (select.value === 'INFRAESTRUCTURA') { // Cambia a 'INFRAESTRUCTURA'
        infra.style.display = 'block';
    } else if (select.value === 'MEDICAMENTO') { // Cambia a 'MEDICAMENTO'
        medi.style.display = 'block';
    }
}


//scrip de campos adicionesles de infraestructura
function agregarFila() {
    const tbody = document.getElementById('detalle-body');
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input type="text" name="item_nombre[]" class="form-control" required></td>
        <td><input type="number" name="item_cantidad[]" class="form-control" required></td>
        <td><input type="text" name="item_unidad[]" class="form-control" required></td>
        <td><input type="number" step="0.01" name="item_costo[]" class="form-control" required></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove()">Eliminar</button></td>
    `;
    tbody.appendChild(tr);
}



