document.addEventListener('DOMContentLoaded', function () {
    const estadoSelect = document.getElementById('estado');
    const municipioSelect = document.getElementById('municipio');
    const parroquiaSelect = document.getElementById('parroquia');
    const ubchSelect = document.getElementById('ubch');
    const comunidadSelect = document.getElementById('comunidad');

    function limpiarSelects(...selects) {
        selects.forEach(select => {
            select.innerHTML = '<option value="">Seleccione una opción</option>';
        });
    }

    function cargarOpciones(tipo, select, params = {}) {
        const url = '../casos/ubicacionCaso.php?' + new URLSearchParams({ tipo, ...params });

        fetch(url)
            .then(res => res.json())
            .then(data => {
                limpiarSelects(select);
                if (data.length > 0) {
                    data.forEach(item => {
                        const option = document.createElement('option');
                        option.value = item.id;
                        option.textContent = item.nombre;
                        select.appendChild(option);
                    });
                } else {
                    const option = document.createElement('option');
                    option.value = '';
                    option.textContent = 'Sin resultados disponibles';
                    select.appendChild(option);
                }
            })
            .catch(err => {
                console.error(`Error cargando ${tipo}:`, err);
            });
    }

    // Cargar estados al iniciar
    cargarOpciones('estado', estadoSelect);

    estadoSelect.addEventListener('change', function () {
        const estadoId = this.value; // Obtiene el ID del estado seleccionado
        limpiarSelects(municipioSelect, parroquiaSelect, ubchSelect, comunidadSelect); // Limpia los selects dependientes
        if (estadoId) {
            fetch(`../casos/ubicacionCaso.php?tipo=municipio&id_estado=${estadoId}`)
                .then(res => res.json())
                .then(data => {
                    municipioSelect.innerHTML = '<option value="">Seleccione</option>';
                    data.forEach(municipio => {
                        municipioSelect.innerHTML += `<option value="${municipio.id}">${municipio.nombre}</option>`;
                    });
                })
                .catch(err => console.error('Error cargando municipios:', err));
        }
    });

    municipioSelect.addEventListener('change', function () {
        const municipioId = this.value; // Obtiene el ID del municipio seleccionado
        limpiarSelects(parroquiaSelect, ubchSelect, comunidadSelect); // Limpia los selects dependientes
        if (municipioId) {
            fetch(`../casos/ubicacionCaso.php?tipo=parroquia&id_municipio=${municipioId}`)
                .then(res => res.json())
                .then(data => {
                    parroquiaSelect.innerHTML = '<option value="">Seleccione</option>';
                    data.forEach(parroquia => {
                        parroquiaSelect.innerHTML += `<option value="${parroquia.id}">${parroquia.nombre}</option>`;
                    });
                })
                .catch(err => console.error('Error cargando parroquias:', err));
        }
    });

    parroquiaSelect.addEventListener('change', function () {
        const parroquiaId = this.value; // Obtiene el ID de la parroquia seleccionada
        limpiarSelects(ubchSelect, comunidadSelect); // Limpia los selects dependientes
        if (parroquiaId) {
            fetch(`../casos/ubicacionCaso.php?tipo=comunidad&id_parroquia=${parroquiaId}`)
                .then(res => res.json())
                .then(data => {
                    comunidadSelect.innerHTML = '<option value="">Seleccione</option>';
                    data.forEach(comunidad => {
                        comunidadSelect.innerHTML += `<option value="${comunidad.id}">${comunidad.nombre}</option>`;
                    });
                })
                .catch(err => console.error('Error cargando comunidades:', err));
        }
    });

    parroquiaSelect.addEventListener('change', function () {
        const parroquiaId = this.value; // Obtiene el ID de la parroquia seleccionada
        limpiarSelects(ubchSelect, comunidadSelect); // Limpia los selects dependientes
        if (parroquiaId) {
            // Cargar UBCH
            fetch(`../casos/ubicacionCaso.php?tipo=ubch&id_parroquia=${parroquiaId}`)
                .then(res => res.json())
                .then(data => {
                    ubchSelect.innerHTML = '<option value="">Seleccione</option>';
                    data.forEach(ubch => {
                        ubchSelect.innerHTML += `<option value="${ubch.id}">${ubch.nombre}</option>`;
                    });
                })
                .catch(err => console.error('Error cargando UBCH:', err));
        }
    });
});
