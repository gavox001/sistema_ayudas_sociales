// Este archivo contiene el código JavaScript para la funcionalidad del dashboard
// de la aplicación web. Se encarga de la interacción con el usuario y la
// visualización de datos mediante gráficos.
// Se utiliza la biblioteca Chart.js para crear gráficos interactivos.


document.addEventListener('DOMContentLoaded', function () {
    // Cargar datos desde consultaDashboard.php
    fetch('../dashboard/consultaDashboard.php') 
        .then(res => res.json())
        .then(data => {
            const ctx = document.getElementById('myChart').getContext('2d');

            // Crear el gráfico
            const myChart = new Chart(ctx, {
                type: 'pie', // Tipo de gráfico (pastel)
                data: {
                    labels: data.labels, // Etiquetas dinámicas (categorías)
                    datasets: [{
                        data: data.values, // Totales dinámicos
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#FF9F40', '#4BC0C0', '#9966FF']
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        title: {
                            display: true,
                            text: 'Distribución de Casos por Tipo de Solicitud'
                        }
                    },
                    onClick: (event, elements) => {
                        if (elements.length > 0) {
                            const index = elements[0].index; // Índice de la sección seleccionada
                            const selectedStats = data.estadisticas[index]; // Obtener estadísticas de la categoría seleccionada
                            updateStats(selectedStats); // Actualizar estadísticas
                        }
                    }
                }
            });

            // Mostrar los datos del primer tipo de caso al cargar
            if (data.estadisticas.length > 0) {
                updateStats(data.estadisticas[0]);
            }
        })
        .catch(error => {
            console.error('Error al cargar los datos del dashboard:', error);
        });
});

// Función para actualizar las estadísticas
function updateStats(data) {
    console.log('Datos para actualizar estadísticas:', data);
    document.getElementById('receivedCount').textContent = data.total;
    document.getElementById('attendedCount').textContent = data.ATENDIDO;
    document.getElementById('pendingCount').textContent = data.EN_PROCESO;
    document.getElementById('notAttendedCount').textContent = data.SIN_ATENDER;
}