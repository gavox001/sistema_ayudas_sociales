<?php
require_once '../includes/conexion.php';

$sql = "SELECT tipo_solicitud,
               COUNT(*) AS total,
               SUM(CASE WHEN estatus_caso = 'SIN ATENDER' THEN 1 ELSE 0 END) AS SIN_ATENDER,
               SUM(CASE WHEN estatus_caso = 'EN PROCESO' THEN 1 ELSE 0 END) AS EN_PROCESO,
               SUM(CASE WHEN estatus_caso = 'ATENDIDO' THEN 1 ELSE 0 END) AS ATENDIDO
        FROM casos
        GROUP BY tipo_solicitud";

$resultado = $conexion->query($sql);

$labels = [];
$values = [];
$estadisticas = [];

if ($resultado && $resultado->rowCount() > 0) {
    while ($fila = $resultado->fetch(mode: PDO::FETCH_ASSOC)) {
        $labels[] = $fila['tipo_solicitud'];
        $values[] = (int)$fila['total'];
        $estadisticas[] = [
            'total' => (int)$fila['total'],
            'ATENDIDO' => (int)$fila['ATENDIDO'],
            'EN_PROCESO' => (int)$fila['EN_PROCESO'],
            'SIN_ATENDER' => (int)$fila['SIN_ATENDER'],
        ];
    }
}

header(header: 'Content-Type: application/json');
echo json_encode(value: [
    'labels' => $labels,
    'values' => $values,
    'estadisticas' => $estadisticas
]);

?>