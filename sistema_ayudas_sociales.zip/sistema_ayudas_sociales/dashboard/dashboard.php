<?php include '../includes/header.php'; ?>

<h1>Panel de Control</h1>



<div id="dashboard" class="formulario">

    <div class="col-md-2"></div>

    <div class="col-md-10">
        <br>
        <br>
        <form action="" method="post">
            <div class="card">
                <div class="card-body">

                    <h5 class="card-title">Distribución de Solicitudes</h5>

                    <br>
                    <br>
                    <div id="stats">
                        <div id="received">Solicitudes Recibidas: <span id="receivedCount">0</span></div>
                        <div id="attended">Casos Atendidos: <span id="attendedCount">0</span></div>
                        <div id="pending">Casos En Proceso: <span id="pendingCount">0</span></div>
                        <div id="notAttended">Casos Sin Atender: <span id="notAttendedCount">0</span></div>
                       
                    </div>
                    <canvas id="myChart"></canvas>
                    <br>
                    <br>
                    

                </div>
                <br>
                <br>
        </form>
    </div>



</div>




<?php include '../includes/footer.php'; ?>

