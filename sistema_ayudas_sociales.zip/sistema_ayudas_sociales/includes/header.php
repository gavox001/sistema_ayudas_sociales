<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Ayudas Sociales</title>

    <!-- Bootstrap CSS -->

    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">

    <link rel="stylesheet" href="../assets/personalizados/styleRetistroCaso.css">
    <link rel="stylesheet" href="../assets/personalizados/styleDashboard.css">
    <link rel="stylesheet" href="../assets/personalizados/styleNavBar.css">


</head>

<body>

    <!-- Menú de navegación -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar">
        <div class="container-fluid">
            <a class="nav-link" href="../dashboard/dashboard.php">Ayudas Sociales</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="menuNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="../casos/formulario_registro.php">Registrar Caso</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="../casos/consultar_casos.php">Consultar Casos</a>
                    </li>

                    <!-- Agrega más enlaces según tus módulos -->
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../usuarios/logout.php">Cerrar Sesión</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>



    <div class="container">