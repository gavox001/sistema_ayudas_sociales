</div> <!-- Cierre del container -->


<!-- Bootstrap JS -->

<script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="../assets/jsPersonalizado/dashboardJS.js"></script>
<script src="../assets/jsPersonalizado/registroCasoJS.js"></script>
<script src="../assets/jsPersonalizado/ubicacionesJS.js"></script>



</body>
</html>
